#! /bin/bash
java -Xmx1G -cp code/Assign4/bin/. nlp.parser.Parser $1 $2
